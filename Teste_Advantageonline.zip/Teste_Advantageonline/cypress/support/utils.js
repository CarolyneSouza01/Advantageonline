const { test } = require('@test-js/test');

const Utils = {

    gerarNomeAleatorio() {
        return test.person.firstName();
    },

    gerarNumeroAleatorioEntre(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

};

module.exports = Utils;