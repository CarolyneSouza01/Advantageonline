import { HomePage } from './home.page';
import { elcat } from '../../support/locators/cart.locator';

class CatPage extends HomePage {

    clicarLinkEditarItem1() {
        cy.get(elcat.linkItem1Edit).click();
    }

    clicarLinkRemoverItem1() {
        cy.get(elcat.linkItem1Remove).click();
    }

    clicarLinkEditarItem2() {
        cy.get(elcat.linkItem2Edit).click();
    }

    clicarLinkRemoverItem2() {
        cy.get(elcat.linkItem2Remove).click();
    }

    clicarBotaoCheckout() {
        cy.get(elcat.btnCheckout).click();
    }

}

export const catPage = new CatPage();